var searchData=
[
  ['close',['CLOSE',['../classSWSE_1_1URLResolverClient.html#a3287e1a5d1cb4cc80b983509a94594e1aa197d4d3f116ced684df2562047f0129',1,'SWSE::URLResolverClient']]]
];
