var searchData=
[
  ['buscador_20web_20por_20similitud_20de_20texto',['Buscador Web por similitud de texto',['../index.html',1,'']]]
];
