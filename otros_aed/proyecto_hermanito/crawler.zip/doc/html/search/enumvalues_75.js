var searchData=
[
  ['url',['URL',['../classSWSE_1_1URLResolverClient.html#a3287e1a5d1cb4cc80b983509a94594e1a2953252f533d084234513e8fb8bf7f4f',1,'SWSE::URLResolverClient']]]
];
