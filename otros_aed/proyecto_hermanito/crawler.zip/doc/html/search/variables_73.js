var searchData=
[
  ['socket_5f',['socket_',['../classSWSE_1_1httpAsyncClient.html#a07fafefe9479887730642598280f11fd',1,'SWSE::httpAsyncClient::socket_()'],['../classSWSE_1_1URLResolverClient.html#a6484062661c092f958db04ec85855d6a',1,'SWSE::URLResolverClient::socket_()']]],
  ['status_5fcode',['status_code',['../classSWSE_1_1httpResponse.html#a51a91c2ac3e7880f14f235dc5e221153',1,'SWSE::httpResponse']]],
  ['status_5fmessage',['status_message',['../classSWSE_1_1httpResponse.html#a617e5c730cd37e761010b10634ff58c8',1,'SWSE::httpResponse']]]
];
