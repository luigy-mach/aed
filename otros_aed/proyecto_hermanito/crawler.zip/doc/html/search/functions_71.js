var searchData=
[
  ['queueurl',['queueURL',['../classSWSE_1_1Crawler.html#a471bd269327e656894f6d9950c65a3b6',1,'SWSE::Crawler']]],
  ['queueurllist',['queueURLlist',['../classSWSE_1_1URLDownloader.html#ad712f367c375a790beb27350a80a7d4a',1,'SWSE::URLDownloader']]]
];
