var searchData=
[
  ['invalidprotocol',['InvalidProtocol',['../classSWSE_1_1InvalidProtocol.html',1,'SWSE']]],
  ['invalidurl',['InvalidURL',['../classSWSE_1_1InvalidURL.html',1,'SWSE']]]
];
