var searchData=
[
  ['save',['save',['../classSWSE_1_1CrawledDataProcessor.html#a7b47fc4ba3d5432f9f79d221ba761a6e',1,'SWSE::CrawledDataProcessor']]],
  ['savedata',['saveData',['../classSWSE_1_1Parser.html#a3d1bf01ea4965938d68db4c555bf304a',1,'SWSE::Parser::saveData()'],['../classSWSE_1_1URLregister.html#a43b6d2d58b3c508dc668f62d0160b972',1,'SWSE::URLregister::saveData()']]],
  ['savequeue',['saveQueue',['../classSWSE_1_1Crawler.html#accd9a59cef8069b2648f5734153171ec',1,'SWSE::Crawler']]],
  ['setdate',['setDate',['../classSWSE_1_1URLResolverClient.html#ace901acb131ebc01d63467241cf164ed',1,'SWSE::URLResolverClient']]],
  ['setfile',['setFile',['../classSWSE_1_1URL.html#a20b52ac4dd69ddc11cc2980250c757f5',1,'SWSE::URL']]],
  ['setheader',['setHeader',['../classSWSE_1_1httpResponse.html#a143f32156cd0c2681e57a3a6ddcece78',1,'SWSE::httpResponse']]],
  ['sethost',['setHost',['../classSWSE_1_1URL.html#ad261d4392a856bda47ab6f62f46876c4',1,'SWSE::URL']]],
  ['setprotocol',['setProtocol',['../classSWSE_1_1URL.html#afae04d78c9be8228d417bdf0679e7119',1,'SWSE::URL']]],
  ['seturl',['setURL',['../classSWSE_1_1httpRequest.html#acb11a63a2db862b809fad657ca922b89',1,'SWSE::httpRequest']]],
  ['seturlresolverclient',['setURLResolverClient',['../classSWSE_1_1Parser.html#a6f0fe17349cb6affdff2b7c69f9cad6f',1,'SWSE::Parser']]],
  ['string',['string',['../classSWSE_1_1URL.html#a59e352b95b83842ccf0121263525fcc3',1,'SWSE::URL']]]
];
