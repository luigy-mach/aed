var searchData=
[
  ['body',['Body',['../classSWSE_1_1httpResponse.html#a883511931cc27a69fe5cc83c0717ea7e',1,'SWSE::httpResponse']]],
  ['buscador_20web_20por_20similitud_20de_20texto',['Buscador Web por similitud de texto',['../index.html',1,'']]]
];
