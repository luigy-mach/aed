var searchData=
[
  ['net_5furi',['Net_uri',['../namespaceSWSE.html#a4f23ae4a5eb21c9e41f9130da56fcf6d',1,'SWSE']]],
  ['numthreads',['NumThreads',['../classSWSE_1_1Crawler.html#ad14105f92f2c9681519009298e0cede4',1,'SWSE::Crawler']]]
];
