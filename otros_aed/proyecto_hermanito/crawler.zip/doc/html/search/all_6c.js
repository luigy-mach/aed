var searchData=
[
  ['loaddata',['loadData',['../classSWSE_1_1URLregister.html#a6f2f3956d96354686a214d1ba55cba5c',1,'SWSE::URLregister']]],
  ['loadqueue',['loadQueue',['../classSWSE_1_1Crawler.html#a076d88c9a2ce09538d862c9bcb9aa183',1,'SWSE::Crawler']]],
  ['lista_20de_20tareas_20pendientes',['Lista de tareas pendientes',['../todo.html',1,'']]]
];
