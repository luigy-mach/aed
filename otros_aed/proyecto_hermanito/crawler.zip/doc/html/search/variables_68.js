var searchData=
[
  ['host',['host',['../classSWSE_1_1URL.html#ad7f9da3908b5e13fe245c4e8308e6800',1,'SWSE::URL']]],
  ['http_5fversion',['http_version',['../classSWSE_1_1httpResponse.html#a0e6bed7991be79a709f50a1ff2cecfba',1,'SWSE::httpResponse']]]
];
