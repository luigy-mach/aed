var searchData=
[
  ['what_5f',['what_',['../classSWSE_1_1URLexception.html#ac061221cbcac9fa1e71329a45bcb2dea',1,'SWSE::URLexception']]]
];
