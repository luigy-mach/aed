var searchData=
[
  ['tamcola',['TamCola',['../classSWSE_1_1Crawler.html#a9eecac8c8569fd2b39bff37eef23eb7f',1,'SWSE::Crawler']]],
  ['threadid',['threadid',['../classSWSE_1_1URLDownloader.html#aa101774e6e494799fd9a8503e0d6fde7',1,'SWSE::URLDownloader']]]
];
