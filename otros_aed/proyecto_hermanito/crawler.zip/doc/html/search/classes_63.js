var searchData=
[
  ['crawleddataprocessor',['CrawledDataProcessor',['../classSWSE_1_1CrawledDataProcessor.html',1,'SWSE']]],
  ['crawler',['Crawler',['../classSWSE_1_1Crawler.html',1,'SWSE']]],
  ['crawler',['Crawler',['../classCrawler.html',1,'']]]
];
