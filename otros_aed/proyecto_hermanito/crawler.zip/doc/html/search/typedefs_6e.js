var searchData=
[
  ['net_5furi',['Net_uri',['../namespaceSWSE.html#a4f23ae4a5eb21c9e41f9130da56fcf6d',1,'SWSE']]]
];
