var searchData=
[
  ['wrapper',['wrapper',['../structSWSE_1_1wrapper.html',1,'SWSE']]]
];
