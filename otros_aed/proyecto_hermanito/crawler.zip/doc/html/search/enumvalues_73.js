var searchData=
[
  ['set_5fdate',['SET_DATE',['../classSWSE_1_1URLResolverClient.html#a3287e1a5d1cb4cc80b983509a94594e1ac438f9e74869dbe5f7b8eb3c55c3a515',1,'SWSE::URLResolverClient']]]
];
