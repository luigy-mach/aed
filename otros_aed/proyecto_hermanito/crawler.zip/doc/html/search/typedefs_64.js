var searchData=
[
  ['data_5ft',['Data_t',['../namespaceSWSE.html#ad43695d0ddd8e9c880c1cfe3d4270cb6',1,'SWSE']]]
];
