var searchData=
[
  ['socket_5ft',['socket_t',['../namespaceSWSE.html#a1856750e4520fcea86f5cb259cc398ac',1,'SWSE']]],
  ['streambuffer',['streambuffer',['../namespaceSWSE.html#a8c6120c778ff7834c72a6dfdbb42242d',1,'SWSE']]]
];
