#include <iostream>
#include <fstream>
#include <string>
#include <boost/archive/text_iarchive.hpp>
#include <boost/serialization/string.hpp>
#include <boost/serialization/concurrent_unordered_map.hpp>
#include <boost/serialization/concurrent_unordered_set.hpp>

using namespace std;

typedef string URLhash_t;
typedef tbb::concurrent_unordered_set<URLhash_t> URLhashSet;
typedef tbb::concurrent_unordered_map<URLhash_t,std::pair<size_t,URLhashSet> > URLHashSetMap;
typedef boost::network::uri::uri Net_uri;

int main()
{
URLHashSetMap m_data;
    std::ifstream ifs("crawlerURLRegister.data");
  if(!ifs.is_open())
  {
    std::cout<<"Error File Register"<<std::endl;
    return 1;
  }
  boost::archive::text_iarchive ia(ifs);
  ia>>m_data;
  for(auto i : m_data)
  {
      if(i.second.first)
        cout<<i.first<<" "<<i.second.first<<endl;
  }
  return 0;
}
