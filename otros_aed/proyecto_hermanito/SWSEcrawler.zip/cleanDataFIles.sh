#!/bin/bash

echo 22 serialization::archive 9 0 0 0 0 0 > "crawlerURLQueue.data"
echo 22 serialization::archive 9 0 0 0 > "crawlerURLRegister.data"
echo 22 serialization::archive 9 0 0 0 > "/home/jose/workspace/EDA/eda-similaritysearchengine/data/idToUrlmap.bin"
echo 22 serialization::archive 9 0 0 0 > "/home/jose/workspace/EDA/eda-similaritysearchengine/data/urlToIdMap.bin"
